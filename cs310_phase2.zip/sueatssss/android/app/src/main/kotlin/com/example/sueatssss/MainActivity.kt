package com.example.sueatssss

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
