class Restaurant {
  final String id;
  final String name;
  final String imageUrl;
  final List<String> cuisineTypes;
  final double rating;
  final int deliveryTime; // in minutes
  final double minOrder;
  final double distance; // in km

  Restaurant({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.cuisineTypes,
    required this.rating,
    required this.deliveryTime,
    required this.minOrder,
    required this.distance,
  });
}