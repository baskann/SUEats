// Cart item model
class CartItem {
  final String name;
  final double price;
  int quantity;

  CartItem({required this.name, required this.price, this.quantity = 1});
}

// Global cart manager
class CartManager {
  static final List<CartItem> items = [
    CartItem(name: 'Margherita Pizza', price: 120.0),
    CartItem(name: 'Pepperoni Pizza', price: 145.0),
  ];

  static void addToCart(String name, double price) {
    // Check for existing item
    for (var item in items) {
      if (item.name == name) {
        item.quantity++;
        return;
      }
    }
    // Add new item
    items.add(CartItem(name: name, price: price));
  }

  static void updateQuantity(int index, int newQuantity) {
    if (index >= 0 && index < items.length) {
      if (newQuantity <= 0) {
        items.removeAt(index);
      } else {
        items[index].quantity = newQuantity;
      }
    }
  }

  static double get subtotal => items.fold(
      0, (sum, item) => sum + (item.price * item.quantity));

  static final double deliveryFee = 15.0;
  static final double serviceFee = 5.0;

  static double get total => subtotal + deliveryFee + serviceFee;
}